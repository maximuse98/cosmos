CREATE VIEW client_offer AS
  SELECT
    `cosmos`.`client`.`name`            AS `client_name`,
    `cosmos`.`client`.`surname`         AS `surname`,
    `cosmos`.`client_request`.`request` AS `request`,
    `cosmos`.`client`.`email`           AS `email`,
    `cosmos`.`product`.`name`           AS `product`
  FROM (((`cosmos`.`client`
    JOIN `cosmos`.`client_request` ON ((`cosmos`.`client`.`id` = `cosmos`.`client_request`.`client_id`))) JOIN
    `cosmos`.`request_product` ON ((`cosmos`.`request_product`.`request_id` = `cosmos`.`client_request`.`id`))) JOIN
    `cosmos`.`product` ON ((`cosmos`.`product`.`category` = (SELECT `cosmos`.`product`.`category`
                                                             FROM (`cosmos`.`product`
                                                               JOIN `cosmos`.`request_product`)
                                                             WHERE (`cosmos`.`product`.`id` =
                                                                    `cosmos`.`request_product`.`product_id`)))));
