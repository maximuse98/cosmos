CREATE VIEW statement_invoice AS
  SELECT
    `cosmos`.`client`.`adress`          AS `adress`,
    `cosmos`.`client`.`name`            AS `client_name`,
    `cosmos`.`client`.`surname`         AS `surname`,
    `cosmos`.`client`.`phone`           AS `phone`,
    `cosmos`.`product`.`name`           AS `product_name`,
    `cosmos`.`invoice_product`.`count`  AS `count`,
    `cosmos`.`invoice_product`.`loaded` AS `loaded`
  FROM ((((`cosmos`.`invoice`
    JOIN `cosmos`.`client_order` ON ((`cosmos`.`invoice`.`order_id` = `cosmos`.`client_order`.`id`))) JOIN
    `cosmos`.`client` ON ((`cosmos`.`client_order`.`client_id` = `cosmos`.`client`.`id`))) JOIN
    `cosmos`.`invoice_product` ON ((`cosmos`.`invoice_product`.`invoice_id` = `cosmos`.`invoice`.`id`))) JOIN
    `cosmos`.`product` ON ((`cosmos`.`invoice_product`.`product_id` = `cosmos`.`product`.`id`)))
  WHERE ((`cosmos`.`invoice_product`.`loaded` = 0) AND (`cosmos`.`invoice`.`agreed` = 1));
