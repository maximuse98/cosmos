CREATE TRIGGER create_Order
AFTER UPDATE ON client_request
FOR EACH ROW
  BEGIN
	DECLARE x INT;
	DECLARE y INT;
	SET x = NEW.client_id;
	SET y = NEW.id;
    
    IF NEW.checked = TRUE AND NEW.approved = TRUE THEN
		INSERT INTO Client_Order(client_id,request_id)
		VALUES (x,y);
    
		SET @lastID := LAST_INSERT_ID();
    
		INSERT INTO Order_Product(order_id,product_id,count,rest)
		SELECT @lastID, Request_Product.product_id, Request_Product.count, Request_Product.count FROM Request_Product
		WHERE request_id = NEW.id;
    END IF;
END;
