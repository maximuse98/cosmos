CREATE TRIGGER delete_Client
AFTER DELETE ON client
FOR EACH ROW
  INSERT INTO Client_Archive(id, name, surname, hone, adress, email)
VALUES (OLD.name, OLD.surname, OLD.phone, OLD.adress, OLD.email);
