CREATE PROCEDURE delete_order(IN del_order_id INT)
  BEGIN
    SET @contract = (SELECT contract_id FROM Client_Order WHERE id = del_order_id);
    
	DELETE FROM Client_Order
    WHERE id = del_order_id;
    
	DELETE FROM Order_Product
    WHERE order_id = del_order_id;
    
    INSERT INTO Contract_Archive(contract, begin_date, end_date)
    (SELECT contract, begin_date, end_date 
    FROM Contract WHERE Contract.id = @contract);
    
	DELETE FROM Contract
    WHERE id = @contract;
END;
